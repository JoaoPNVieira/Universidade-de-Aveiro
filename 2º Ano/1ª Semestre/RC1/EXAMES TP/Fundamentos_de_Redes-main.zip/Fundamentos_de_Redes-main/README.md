# Fundamentos_de_Redes
Material relativo às aulas Teórico-Práticas e resolução de Guiões Práticos da UC de Fundamentos de Redes
