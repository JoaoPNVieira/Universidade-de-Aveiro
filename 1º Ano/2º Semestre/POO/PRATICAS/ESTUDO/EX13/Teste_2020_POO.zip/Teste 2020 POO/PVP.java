package teste;

public interface PVP {
	public double precoVendaAoPublico();
}
