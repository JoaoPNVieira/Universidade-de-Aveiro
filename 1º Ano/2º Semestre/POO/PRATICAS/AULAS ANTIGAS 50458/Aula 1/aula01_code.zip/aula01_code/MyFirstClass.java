package aula01;

public class MyFirstClass {

	public static void main(String[] args) {
		System.out.println("Hello Eclipse!");
		int sum = 0;
		for (int i = 1; i <= 100; i++) {
			sum += i;
		}
		System.out.println(sum);
	}
}
